
declare module 'basic-ui-lib' {

import React from 'react';
import { AgGridReact,AgGridReactProps } from 'ag-grid-react';
import type { IconButtonProps } from '@mui/material';
import type { CSSProperties } from 'react';
import type {
  AutocompleteChangeDetails,
  AutocompleteChangeReason,
  AutocompleteInputChangeReason,
} from '@mui/base/useAutocomplete/useAutocomplete'; 

  export interface TebDataGridEnterpriseProps extends AgGridReactProps {
    style?: CSSProperties;
    [key: string]: any;
  }
  export const TebDataGridEnterprise: React.ForwardRefExoticComponent<TebDataGridEnterpriseProps & React.RefAttributes<AgGridReact>>;

export type {
  // Grid core
  GridOptions,
  GridApi,
  GridState,
  GridReadyEvent,
  // Column definitions
  ColDef,
  ColGroupDef,
  ColTypeDef,
  ColTypeDefs,
  // Column state
  Column,
  ColumnGroup,
  ColumnState,
  ApplyColumnStateParams,
  // Row node
  IRowNode,
  RowPinnedType,
  // Events
  CellClickedEvent,
  CellValueChangedEvent,
  RowClickedEvent,
  RowDoubleClickedEvent,
  SelectionChangedEvent,
  FilterChangedEvent,
  SortChangedEvent,
  SortModelItem,
  // Value callbacks
  ValueGetterParams,
  ValueSetterParams,
  ValueFormatterParams,
  ValueParserParams,
  // Cell renderer / editor
  ICellRendererParams,
  ICellEditorParams,
  // Cell range (enterprise)
  CellRange,
  CellRangeParams,
  // Data transactions
  RowDataTransaction,
  RowNodeTransaction,
  ServerSideTransaction,
  ServerSideTransactionResult,
  // Datasources
  IDatasource,
  IGetRowsParams,
  IServerSideDatasource,
  IServerSideGetRowsParams,
  IServerSideGetRowsRequest,
  // Filter types
  IFilterParams,
  TextFilterModel,
  NumberFilterModel,
  DateFilterModel,
  // Cell editor params
  ILargeTextEditorParams,
  INumberCellEditorParams,
  ISelectCellEditorParams,
  ITextCellEditorParams,
  // UI definitions
  MenuItemDef,
  SideBarDef,
  ToolPanelDef,
  // Export
  CsvExportParams,
  ExcelExportParams,
} from 'ag-grid-community';

export enum ButtonVariant {
    primary = 'primary',
    secondary = 'secondary',
    text = 'text',
  }

  export enum ButtonType {
    button = 'button',
    submit = 'submit',
    reset = 'reset',
  } 

  export interface TebButtonProps {
    size: InputSize;
    variant: ButtonVariant;
    disabled?: boolean;
    type: ButtonType;
    destructive?: boolean;
    id?: string;
    form?: string;
    tabIndex?: number;
    style?: React.CSSProperties;
    children?: string | JSX.Element | JSX.Element[];
    shouldPropagate?: boolean;
    shouldPrevent?: boolean;
    onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
    iconName?: string;

    loading?: boolean;
  }

  export const TebButton: React.FC<TebButtonProps>;  


export enum InputSize {
  small = 'small',
  medium = 'medium',
  large = 'large',
} 
  export interface TebAutoCompleteProps<T> {
    id?: string;
    name?: string;
    label?: string;
    tabIndex?: number;
    options: T[];
    value?: T | null;
    disabled: boolean;
    inputValue?: string;
    helperText?: string;
    helperIcon?: string;
    placeholder?: string;
    error: boolean;
    width?: string | number;
    zIndex?: number;
    size: InputSize;
    margin?: string | number;
    noOptionsText: React.ReactNode;
    getOptionLabel?: (option: T) => string;
    isOptionEqualToValue?: (option: T, value: T) => boolean;
    onChange?: (
      event: React.SyntheticEvent,
      value: T | null,
      reason: AutocompleteChangeReason,
      details?: AutocompleteChangeDetails<T>,
    ) => void;
    onInputChange?: (
      event: React.SyntheticEvent,
      value: string,
      reason: AutocompleteInputChangeReason,
    ) => void;
  } 
  export const TebAutoComplete: React.FC<TebAutoCompleteProps<any>>; // Placeholder for actual props



export interface TreeNode {
  id: string;
  name: string | React.ReactNode;
  parentId?: string;
  children?: TreeNode[];
}

export interface TreeItemClickPayload {
  id: string;
  name: string | React.ReactNode;
  selected: boolean | null;
}

interface TebTreeViewBaseProps {
  /** Tree data – supports unlimited nesting */
  data: TreeNode[];
  /** Tab index forwarded to each focusable row */
  tabIndex?: number;
  /** When true, checkboxes (20×20 px) are shown before each label */
  hasCheckbox?: boolean;
  /** Called when loadChildrenDynamically is true and a node is clicked; must return the children to inject */
  onLoadChildren?: (node: TreeNode) => TreeNode[];
  /** Fired whenever any row is clicked; returns id, name and selected state */
  onTreeItemClicked?: (payload: TreeItemClickPayload) => void;
  /** Fired ONLY when a checkbox is toggled; receives all currently-selected nodes */
  onTreeItemSelected?: (selectedItems: TreeNode[]) => void;
  /** When true, shows box shadow and rounded border around the tree. Default: true */
  hasBorder?: boolean;
}

export type TebTreeViewProps = TebTreeViewBaseProps & (
  | {
      /** Dynamic child loading is active – activeItemId is not supported in this mode */
      loadChildrenDynamically: true;
      activeItemId?: never;
    }
  | {
      loadChildrenDynamically?: false;
      /** The id of the TreeNode that should be visually selected. */
      activeItemId?: string;
    }
);

export const TebTreeView: React.FC<TebTreeViewProps>;

export enum HeaderVariant {
    default = 'default',
    shadowed = 'shadowed',
  } 
export interface TebRichHeaderProps {
    primaryTitle: React.ReactNode | string;
    secondaryTitle?: React.ReactNode | string;
    centerSlot?: React.ReactNode | string;
    infoLabel: React.ReactNode | string;
    variant: HeaderVariant;
    primaryIcon: string;
    secondaryIcon: string;
    onPrimaryAction: (event: React.MouseEvent<HTMLOrSVGElement>) => void;
    onSecondaryAction: (event: React.MouseEvent<HTMLOrSVGElement>) => void;
  }

  export const TebRichHeader: React.FC<TebRichHeaderProps>;

export interface TebCheckBoxProps {
    id?: string;
    name?: string;
    tabIndex?: number;
    disabled?: boolean;
    checked?: boolean;
    indeterminate?: boolean;
    error?: boolean;
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    label?: string;
    margin?: string | number;
  }

  export const TebCheckBox: React.FC<TebCheckBoxProps>; 

  export type TebComboBoxOption = {
    id: string;
    selected: boolean;
    label: string;
  };

  export interface TebComboBoxProps {
    id: string;
    name?: string;
    value?: TebComboBoxOption;
    tabIndex: number;
    suffix?: React.ReactElement;
    placeholder?: string;
    assistiveText?: string;
    error?: boolean;
    disabled?: boolean;
    width?: string | number;
    icon?: string;
    open: boolean;
    size: InputSize;
    useChips?: boolean;
    options: TebComboBoxOption[];
    multiple?: boolean;
    margin?: string | number;
    onClear?: () => void;
    onOpen?: (visible: boolean) => void;
    onClose?: (visible: boolean) => void;
    onInputBlur?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onInputChange?: (value: TebComboBoxOption | TebComboBoxOption[]) => void;
  }

  export const TebComboBox: React.ForwardRefExoticComponent< TebComboBoxProps & React.RefAttributes<HTMLInputElement>>; 

export interface TebIconButtonProps extends Omit<IconButtonProps, 'color'> {
    id?: string;
    tabIndex?: number;
    icon: React.ReactElement<React.JSX.IntrinsicElements, 'svg'>;
    onClick: (event: React.MouseEvent<HTMLButtonElement>) => void;
    disabled?: boolean;
    shouldPropagate?: boolean;
    shouldPrevent?: boolean;
    style?: React.CSSProperties;
  }

  export const TebIconButton: React.FC<TebIconButtonProps>; 
  
  export enum InputType {
    button = 'button',
    submit = 'submit',
    reset = 'reset',
    text = 'text',
    number = 'number',
    tel = 'tel',
    email = 'email',
    password = 'password',
    textarea = 'textarea',
  }

  export type keytype = { shiftKey: boolean; key: string }; 
   
  export interface TebInputProps {
    id: string;
    name?: string;
    value: string | number;
    type: InputType;
    tabIndex: number;
    mandatory?: boolean;
    onInputChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onInputBlur?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onIconClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
    onKeydown?: (value: keytype) => void;
    suffix?: React.ReactElement;
    placeholder?: string;
    assistiveText?: string;
    error?: boolean;
    readonly?: boolean;
    disabled?: boolean;
    width?: string | number;
    size: InputSize;
    icon?: string;
    margin?: string | number;
    editable?: boolean;
    maxlength?: number;
    validation?: RegExp;
    country?: 'TR' | 'US';
  }

  export const TebInput: React.ForwardRefExoticComponent< TebInputProps & React.RefAttributes<HTMLInputElement>>; 
  
  export enum CardVariant {
    regular = 'regular',
    table = 'table',
    customer = 'customer',
    accordion = 'accordion',
  } 

  export interface TebCardProps {
    title?: string;
    width?: string | number;
    height?: string | number;
    variant?: CardVariant;
    actions?: React.ReactNode;
    children?: React.ReactNode;
    hasDefaultOverflow?: boolean;
    disableVerticalScroll?: boolean;
    disableHorizontalScroll?: boolean;
  }

export const TebCard: React.FC<TebCardProps>; 

export type ChipVariant = 'default' | 'selected'; 

export interface TebChipProps {
  label: string;
  variant?: ChipVariant;
  onDelete?: () => void;
  onClick?: () => void;
  size?: 'small' | 'medium';
  id?: string;
  tabIndex?: number;
  editable?: boolean;
  labelValidationRule?: RegExp;
}

 export const TebChip: React.FC<TebChipProps>

// Responsive value type for t-shirt sizes and gaps
export type ResponsiveValue<T> = {
  xs?: T;
  sm?: T;
  md?: T;
  lg?: T;
  xl?: T;
  xxl?: T;
};

 export interface TebLayoutGridProps {
    size?: number;
    columns?: number;
    //xs?: number;
    sm?: number;
    md?: number;
    lg?: number;
    //xl?: number;
    //xxl?: number;
    container?: boolean;
    child?: boolean;
    children: React.ReactNode;
    spacing?: string | ResponsiveValue<string>;
    rowSpacing?: string | ResponsiveValue<string>;
    columnSpacing?: string | ResponsiveValue<string>;
    alignment?: 'start' | 'center' | 'end' | 'stretch';
    justifyContent?:
      | 'start'
      | 'center'
      | 'end'
      | 'space-between'
      | 'space-around';
    span?: number | ResponsiveValue<number>;
    order?: number;
    wrap?: 'wrap' | 'wrap-reverse';
    className?: string;
    style?: React.CSSProperties;
  }

  export const TebLayoutGrid: React.FC<TebLayoutGridProps>;

}

declare module '*.scss' {
  const styles: { [className: string]: string };
  export default styles;
}

declare module '*.css' {
  const styles: { [className: string]: string };
  export default styles;
}
